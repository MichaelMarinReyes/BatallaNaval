package com.backend.principal;

import com.frontend.ventanaymenus.FramePrincipal;

/**
 *
 * @author michael
 */
public class Main {

    public static void main(String[] args) {
        FramePrincipal ventana = new FramePrincipal();
        ventana.setVisible(true);
    }
}
