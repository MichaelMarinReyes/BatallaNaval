package com.backend.menus;

/**
 *
 * @author michael
 */
public class NuevaPartida {
    
    public void validarArregloVacio() {
        crearNuevaPartida();
    }
    
    public void mostrarPrevisualizador() {
        
    }
    
    public void crearNuevaPartida() {
        
    }
}
