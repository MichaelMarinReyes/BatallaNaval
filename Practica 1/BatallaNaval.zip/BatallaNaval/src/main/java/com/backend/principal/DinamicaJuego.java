package com.backend.principal;

import com.backend.componentestablero.Tablero;

/**
 *
 * @author michael
 */
public class DinamicaJuego {
    Tablero tablero;
    Usuario jugador;
}
