package com.backend.menus;

/**
 *
 * @author michael
 */
public class Puntaje {
    
}
